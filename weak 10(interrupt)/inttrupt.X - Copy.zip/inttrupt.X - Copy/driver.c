/*
 * File:   driver.c
 * Author: SURIYARAJ
 *
 * Created on 21 February 2024, 18:46
 */


#include <xc.h>
#include"intguard.h"
#define _XTAL_FREQ 6000000

void init()
{
    TRISB=0x01;
    PORTB=0x00;
    TRISD=0xFE;
    PORTD=0x00;
    TRISC=0x00;
    PORTC=0x00;
    OPTION_REG&=0x7F;
    INTCON|=0x90;
    
}
void __interrupt() ISR()
{
    if(INTCON&0x02)
    {
      PORTD=0x01; 
      __delay_ms(1000);
    }
    INTCON&=~0x02;
}